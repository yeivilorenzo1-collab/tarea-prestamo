(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_ec1c52de._.js",
  "static/chunks/src_app_user_page_jsx_69b5f291._.js"
],
    source: "dynamic"
});
