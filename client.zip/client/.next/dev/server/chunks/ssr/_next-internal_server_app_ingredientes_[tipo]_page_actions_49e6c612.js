module.exports = [
"[project]/.next-internal/server/app/ingredientes/[tipo]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_ingredientes_%5Btipo%5D_page_actions_49e6c612.js.map