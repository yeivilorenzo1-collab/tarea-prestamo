module.exports = [
"[project]/.next-internal/server/app/ingredientes/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_ingredientes_page_actions_7acbb4a9.js.map