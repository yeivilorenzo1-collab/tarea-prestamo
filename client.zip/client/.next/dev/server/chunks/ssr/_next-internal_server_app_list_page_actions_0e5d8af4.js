module.exports = [
"[project]/.next-internal/server/app/list/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_list_page_actions_0e5d8af4.js.map