module.exports = [
"[project]/.next-internal/server/app/user/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_user_page_actions_3ada4e8f.js.map