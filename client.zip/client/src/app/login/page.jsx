

// login/page.jsx
"use client";
import { useState } from "react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");

  const handleLogin = () => {
    // Aquí puedes validar si todo está correcto
    window.location.href = "/user"; // 🔥 Entra al menú de pizzas
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-green-100">
      <div className="bg-white p-6 rounded-xl shadow-xl w-full max-w-sm">
        <h1 className="text-2xl font-bold mb-4 text-center">Iniciar Sesión</h1>

        <input
          type="email"
          placeholder="Correo"
          onChange={(e) => setEmail(e.target.value)}
          className="w-full p-2 mb-3 border rounded-lg"
        />

        <input
          type="password"
          placeholder="Contraseña"
          onChange={(e) => setPass(e.target.value)}
          className="w-full p-2 mb-3 border rounded-lg"
        />

        <button
          onClick={handleLogin}
          className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
        >
          Entrar
        </button>

        <p className="text-center mt-4 text-sm">
          ¿No tienes cuenta?{" "}
          <a href="/register" className="text-blue-500 font-medium">
            Regístrate aquí
          </a>
        </p>
      </div>
    </div>
  );
}
