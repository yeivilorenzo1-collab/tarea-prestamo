

"use client";

import { useState } from "react";
import HomePage from "./components/home_page";
import Navbar from "./components/navbar";

export default function Home() {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="bg-background-light dark:bg-background-dark font-display flex flex-col min-h-screen">
      <Navbar login={isLogin} />
      <HomePage />
    </div>
  );
}

