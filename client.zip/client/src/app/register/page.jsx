

// register/page.jsx
"use client";

import { useState } from "react";

export default function Register() {
  const [name, setName] = useState("");

  const handleRegister = () => {
    // Guardar datos o validar (opcional)
    window.location.href = "/login"; // 🔥 Después de registrarse va al login
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-green-100">
      <div className="bg-white p-6 rounded-xl shadow-xl w-full max-w-sm">
        <h1 className="text-2xl font-bold mb-4 text-center">Crear Cuenta</h1>

        <input
          type="text"
          placeholder="Nombre completo"
          className="w-full p-2 mb-3 border rounded-lg"
          onChange={(e) => setName(e.target.value)}
        />

        <input
          type="email"
          placeholder="Correo"
          className="w-full p-2 mb-3 border rounded-lg"
        />

        <input
          type="password"
          placeholder="Contraseña"
          className="w-full p-2 mb-3 border rounded-lg"
        />

        <input
          type="password"
          placeholder="Confirmar Contraseña"
          className="w-full p-2 mb-4 border rounded-lg"
        />

        <button
          onClick={handleRegister}
          className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700"
        >
          Registrarse
        </button>

        <p className="text-center mt-4 text-sm">
          ¿Ya tienes cuenta?{" "}
          <a href="/login" className="text-blue-500 font-medium">
            Inicia sesión
          </a>
        </p>
      </div>
    </div>
  );
}
