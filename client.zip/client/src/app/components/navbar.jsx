

"use client";

export default function Navbar({ login }) {
  return (
    <header className="w-full px-8 py-4 border-b border-gray-200 dark:border-gray-700">
      <nav className="flex justify-between items-center">
        {/* LOGO */}
        <div className="flex items-center space-x-2">
          <span
            className="material-icons text-primary"
            style={{ transform: "rotate(180deg)" }}
          >
            fmd_good
          </span>
          <span className="font-bold text-lg text-gray-800 dark:text-gray-200">
            StudyCentral
          </span>
        </div>

        {/* MENÚ */}
        {login && (
          <div className="flex items-center space-x-6 text-sm font-medium">
            <a className="text-gray-700 dark:text-gray-300 hover:text-primary" href="#">
              Inicio
            </a>
            <a className="text-gray-700 dark:text-gray-300 hover:text-primary" href="#">
              Cursos
            </a>
            <a className="text-gray-700 dark:text-gray-300 hover:text-primary" href="#">
              Calendario
            </a>
            <a className="text-gray-700 dark:text-gray-300 hover:text-primary" href="#">
              Recursos
            </a>
          </div>
        )}
      </nav>
    </header>
  );
}
