

"use client";
import Image from "next/image";

export default function Bienvenida() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-red-100 p-6">

      {/* Imagen grande portada arriba */}
      <Image
        src="/portada.png"
        alt="Portada"
        width={350}
        height={350}
        className="rounded-xl mb-6 shadow-lg"
      />

      <div className="flex flex-col items-center">
        <Image
          src="/pizza-logo.avif"
          alt="logo"
          width={160}
          height={160}
          className="mb-4"
        />

        <h1 className="text-3xl font-bold text-red-700 text-center">
          ¡Bienvenido a PizzaApp!
        </h1>

        <p className="text-gray-700 mt-2 text-center max-w-xs">
          La mejor forma de ordenar tu pizza favorita 🍕🔥
        </p>

        <div className="mt-6 w-full flex flex-col gap-3">
          <a
            href="/login"
            className="w-full bg-red-600 text-white py-2 px-4 rounded-xl text-center font-semibold hover:bg-red-700"
          >
            Iniciar Sesión
          </a>

          <a
            href="/register"
            className="w-full bg-gray-800 text-white py-2 px-4 rounded-xl text-center font-semibold hover:bg-black"
          >
            Registrarse
          </a>
        </div>
      </div>

    </div>
  );
}
