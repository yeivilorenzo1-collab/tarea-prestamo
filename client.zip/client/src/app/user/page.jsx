"use client";
import Image from "next/image";
import Link from "next/link";

export default function User() {
  const pizzas = [
    { nombre: "vegetariana", precio: 450, img: "/pizza-v.webp" },
    { nombre: "no-vegetariana", precio: 500, img: "/pizza-nv.jpg" },
  ];

  return (
    <div className="min-h-screen bg-red-100 p-6">
      <h1 className="text-3xl font-bold text-center mb-6">🍕 Menú de Pizzas</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {pizzas.map((p, i) => (
          <div
            key={i}
            className="bg-white shadow-lg rounded-2xl p-5 hover:scale-105 transition cursor-pointer"
          >
            <div className="w-full h-60 bg-gray-200 rounded-2xl overflow-hidden flex items-center justify-center">
              <Image
                src={p.img}
                width={600}
                height={600}
                className="object-cover w-full h-full"
                alt={p.nombre}
              />
            </div>

            <h2 className="text-xl font-semibold mt-4 capitalize">
              Pizza {p.nombre.replace("-", " ")}
            </h2>

            <p className="text-gray-700 font-medium">RD$ {p.precio}</p>

            <Link href={`/ingredientes/${p.nombre}`}>
              <button className="w-full mt-4 bg-red-500 hover:bg-red-600 text-white py-3 rounded-xl text-lg font-semibold">
                Ver ingredientes 👀
              </button>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}

