

"use client";
import { useSearchParams } from "next/navigation";
import { useState } from "react";

export default function FacturaPage() {
  const searchParams = useSearchParams();
  const tipo = searchParams.get("tipo");
  const ingredientes = decodeURIComponent(
    searchParams.get("ingredientes") || ""
  ).split(",");

  // Precios según tipo de pizza
  const preciosPorPizza = {
    vegetariana: 450,
    "no-vegetariana": 500,
  };

  const subtotal = preciosPorPizza[tipo.toLowerCase()] || 0;
  const impuestos = Math.round(subtotal * 0.15); // ejemplo 15%
  const total = subtotal + impuestos;

  const [confirmado, setConfirmado] = useState(false);

  return (
    <div className="min-h-screen bg-red-200 flex flex-col items-center p-6">
      <div className="bg-white rounded-2xl shadow-lg p-8 w-full max-w-md">
        <h1 className="text-3xl font-bold text-center text-black mb-4">
          Resumen de tu pedido
        </h1>
        <p className="text-center text-yellow-700 mb-6">
          Por favor, revisa los detalles de tu pedido antes de confirmar.
        </p>

        <div className="space-y-3 text-lg">
          <div className="flex justify-between">
            <span className="font-semibold">Tipo:</span>
            <span>{tipo}</span>
          </div>
          <div className="flex justify-between">
            <span className="font-semibold">Sabor:</span>
            <span>{ingredientes.join(", ")}</span>
          </div>
          <div className="flex justify-between">
            <span className="font-semibold">Subtotal:</span>
            <span>RD$ {subtotal}</span>
          </div>
          <div className="flex justify-between">
            <span className="font-semibold">Impuestos:</span>
            <span>RD$ {impuestos}</span>
          </div>
          <div className="flex justify-between font-bold text-green-800 text-xl mt-4 border-t pt-3">
            <span>Total:</span>
            <span>RD$ {total}</span>
          </div>
        </div>

        <div className="flex justify-between mt-8">
          <button
            onClick={() => alert("Pedido cancelado")}
            className="bg-red-500 hover:bg-red-600 text-white py-3 px-6 rounded-xl font-semibold transition"
          >
            Cancelar
          </button>
          <button
            onClick={() => setConfirmado(true)}
            className="bg-green-500 hover:bg-green-600 text-white py-3 px-6 rounded-xl font-semibold transition"
          >
            Confirmar compra
          </button>
        </div>

        {confirmado && (
          <p className="mt-6 text-center text-green-700 font-semibold">
            ¡Pedido confirmado! 🍕
          </p>
        )}
      </div>
    </div>
  );
}
