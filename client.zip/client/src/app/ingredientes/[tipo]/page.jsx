

"use client";
import { useParams, useRouter } from "next/navigation";
import { useState } from "react";

export default function IngredientesPage() {
  const params = useParams();
  const tipo = params.tipo;
  const router = useRouter();

  // Creamos el array fuera del render para que no se regenere
  const ingredientesPorPizza = {
    vegetariana: [
      { nombre: "Queso", emoji: "🧀" },
      { nombre: "Tomate", emoji: "🍅" },
      { nombre: "Pimiento", emoji: "🌶️" },
      { nombre: "Cebolla", emoji: "🧅" },
      { nombre: "Aceitunas", emoji: "🟢" },
    ],
    "no-vegetariana": [
      { nombre: "Queso", emoji: "🧀" },
      { nombre: "Pepperoni", emoji: "🍕" },
      { nombre: "Jamón", emoji: "🥩" },
      { nombre: "Tocino", emoji: "🥓" },
      { nombre: "Salami", emoji: "🥪" },
    ],
  };

  const ingredientes = ingredientesPorPizza[tipo] || [];

  const [seleccionados, setSeleccionados] = useState([]);

  const toggleIngrediente = (nombre) => {
    setSeleccionados((prev) =>
      prev.includes(nombre)
        ? prev.filter((i) => i !== nombre)
        : [...prev, nombre]
    );
  };

  const irAFactura = () => {
    if (seleccionados.length === 0) {
      alert("Selecciona al menos un ingrediente antes de continuar.");
      return;
    }
    const query = new URLSearchParams({
      tipo,
      ingredientes: encodeURIComponent(seleccionados.join(",")),
    }).toString();
    router.push(`/factura?${query}`);
  };

  if (!ingredientes.length) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-green-50">
        <h1 className="text-2xl font-bold text-red-600">
          Tipo de pizza no encontrado.
        </h1>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-green-50 flex flex-col items-center p-6">
      <h1 className="text-3xl font-bold text-center mb-6 text-black">
        Elige los ingredientes para tu pizza {tipo.replace("-", " ")}
      </h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-6 justify-items-center">
        {ingredientes.map((ing) => (
          <div
            key={ing.nombre}
            className="flex items-center justify-between bg-green-400 text-white rounded-2xl p-5 cursor-pointer hover:bg-green-500 transition w-72"
            onClick={() => toggleIngrediente(ing.nombre)}
          >
            <span className="text-xl font-semibold">
              {ing.emoji} {ing.nombre}
            </span>
            <input
              type="checkbox"
              checked={seleccionados.includes(ing.nombre)}
              readOnly
              className="w-6 h-6 accent-yellow-400"
            />
          </div>
        ))}
      </div>

      {seleccionados.length > 0 && (
        <div className="mt-6 text-center">
          <div className="p-4 bg-green-100 rounded-xl text-green-900 font-semibold text-base w-80 mx-auto">
            Ingredientes seleccionados: {seleccionados.join(", ")}
          </div>

          <button
            onClick={irAFactura}
            className="mt-4 bg-blue-500 hover:bg-blue-600 text-white py-3 px-6 rounded-xl font-semibold transition"
          >
            Continuar a Factura 🧾
          </button>
        </div>
      )}
    </div>
  );
}
